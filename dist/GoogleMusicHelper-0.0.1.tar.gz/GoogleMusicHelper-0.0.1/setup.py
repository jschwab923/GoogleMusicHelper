from setuptools import setup, find_packages
from setuptools import setup
from setuptools.command.install import install


class CustomInstallCommand(install):
    def run(self):
        install.run(self)
        from GoogleMusicHelper import sync_playlists_with_library
        sync_playlists_with_library()

setup(
    cmdclass={
        'install': CustomInstallCommand,
    },
    name="GoogleMusicHelper",
    version="0.0.1",
    packages=find_packages(),
)
